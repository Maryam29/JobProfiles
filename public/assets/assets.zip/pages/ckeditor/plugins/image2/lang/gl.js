/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'gl', {
	alt: 'Texto alternativo',
	btnUpload: 'Enviar ao servidor',
	captioned: 'Imaxe con lenda',
	captionPlaceholder: 'Lenda',
	infoTab: 'Información da imaxe',
	lockRatio: 'Proporcional',
	menu: 'Propiedades da imaxe',
	pathName: 'Imaxe',
	pathNameCaption: 'lenda',
	resetSize: 'Tamaño orixinal',
	resizer: 'Prema e arrastre para axustar o tamaño',
	title: 'Propiedades da imaxe',
	uploadTab: 'Cargar',
	urlMissing: 'Non se atopa o URL da imaxe.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
